<!-- home -->
<template>
  <div class="index-container">
    <h1>404!</h1>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: []
    };
  },

  computed: {},

  mounted() {
  },

  methods: {}
};
</script>
