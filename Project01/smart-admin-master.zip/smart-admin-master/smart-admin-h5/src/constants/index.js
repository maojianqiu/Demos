import school from '@/constants/school';
import erp from './erp';

export default {
  ...school,
  ...erp
};
