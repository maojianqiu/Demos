<template>
  <div id="app">
    <router-view />
  </div>
</template>
<script>
export default {
  name: 'App'
};
</script>
<style lang="scss">
#nprogress .bar {
  background: #1989fa !important;
}
</style>

