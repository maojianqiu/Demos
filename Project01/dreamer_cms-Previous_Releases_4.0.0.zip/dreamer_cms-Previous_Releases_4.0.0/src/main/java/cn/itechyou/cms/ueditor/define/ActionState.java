package cn.itechyou.cms.ueditor.define;

public enum ActionState {
	UNKNOW_ERROR
}
