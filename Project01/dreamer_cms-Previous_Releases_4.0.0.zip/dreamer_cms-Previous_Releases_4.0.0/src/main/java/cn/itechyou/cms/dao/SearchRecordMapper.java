package cn.itechyou.cms.dao;

import cn.itechyou.cms.common.BaseMapper;
import cn.itechyou.cms.entity.SearchRecord;

public interface SearchRecordMapper extends BaseMapper<SearchRecord> {
}