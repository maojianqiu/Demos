package cn.itechyou.cms.service;

import cn.itechyou.cms.entity.System;

public interface SystemService {

	System getSystem();

	int update(System system);

}
