package cn.itechyou.cms.service;

import cn.itechyou.cms.entity.SearchRecord;

public interface SearchRecordService {

	int add(SearchRecord sr);

}
