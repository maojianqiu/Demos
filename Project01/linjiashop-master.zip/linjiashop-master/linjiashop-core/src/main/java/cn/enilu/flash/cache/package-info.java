/**
 * package-info
 *
 * @version 2018/9/11 0011
 * @author enilu
 */
package cn.enilu.flash.cache;