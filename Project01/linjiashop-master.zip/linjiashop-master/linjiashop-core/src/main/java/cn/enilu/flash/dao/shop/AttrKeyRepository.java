package cn.enilu.flash.dao.shop;


import cn.enilu.flash.bean.entity.shop.AttrKey;
import cn.enilu.flash.dao.BaseRepository;


public interface AttrKeyRepository extends BaseRepository<AttrKey,Long>{

}

