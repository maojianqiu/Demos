/**
 * Created  on 2018/3/28 0028.
 *
 * @author enilu
 */
package cn.enilu.flash.bean.constant;