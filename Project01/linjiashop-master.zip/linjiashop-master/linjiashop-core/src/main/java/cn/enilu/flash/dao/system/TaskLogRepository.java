
package cn.enilu.flash.dao.system;


import cn.enilu.flash.bean.entity.system.TaskLog;
import cn.enilu.flash.dao.BaseRepository;

public interface TaskLogRepository  extends BaseRepository<TaskLog,Long> {

}
