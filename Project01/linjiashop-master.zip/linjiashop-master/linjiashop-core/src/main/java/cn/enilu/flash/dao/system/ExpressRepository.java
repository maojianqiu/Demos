package cn.enilu.flash.dao.system;


import cn.enilu.flash.bean.entity.system.Express;
import cn.enilu.flash.dao.BaseRepository;


public interface ExpressRepository extends BaseRepository<Express,Long>{

}

