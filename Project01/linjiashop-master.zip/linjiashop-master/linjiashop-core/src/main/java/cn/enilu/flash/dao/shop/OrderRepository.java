package cn.enilu.flash.dao.shop;


import cn.enilu.flash.bean.entity.shop.Order;
import cn.enilu.flash.dao.BaseRepository;


public interface OrderRepository extends BaseRepository<Order,Long>{

}

