package cn.enilu.flash.bean.vo.shop;

import lombok.Data;

/**
 * @author ：enilu
 * @date ：Created in 1/4/2020 10:55 PM
 */
@Data
public class Base64File {
    private String base64;
    private String name;
    private String type;
}
