package cn.enilu.flash.bean.vo.node;

import lombok.Data;

/**
 * @author ：enilu
 * @date ：Created in 2019/10/30 22:01
 */
@Data
public class MenuMeta {
    private String title;
    private String icon;
}
