# 克隆本项目

本项目地址为：[https://gitee.com/microapp/linjiashop](https://gitee.com/microapp/linjiashop),如果对你有用，欢迎给个star

另附github地址：https://github.com/microapp-store/linjiashop

项目共三个分支分别为：
- master 项目主分支：稳定版
- dev 开发分支：一些新功能后者实验性功能会先在该分支开发，不稳定
- gh-pages 项目在线文档

进入控制台输入以下命令将项目克隆到本地：

git clone https://gitee.com/microapp/linjiashop.git
