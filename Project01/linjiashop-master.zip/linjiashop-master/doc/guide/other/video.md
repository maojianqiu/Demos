# 开发视频

**入门视频**
- [https://space.bilibili.com/525325274/channel/detail?cid=115895](https://space.bilibili.com/525325274/channel/detail?cid=115895)
- 上述入门视频基本可以带你快速熟悉本项目并进行开发。相信我，如果你能将本文档认真看看，那么你连视频教程都不用看的。文档最重要！！！


- 当然本系统录制有更全面的视频教程，如果你感兴趣可以通过下面方式获取。
    - 方式一：邀请好友给以下两个项目star 8个(是合计8个，不是每个8个)即可。[linjiashop](https://gitee.com/microapp/linjiashop),[web-flash](https://gitee.com/enilu/web-flash)
