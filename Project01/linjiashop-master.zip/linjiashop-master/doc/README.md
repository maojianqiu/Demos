---
home: true
heroImage: /logo.jpg
heroText: ''
actionText: 快速开始 →
actionLink: /guide/base/preface
footer: MIT Licensed | Copyright © 2019-present microapp.store
---

<div style="text-align: center">
  <Bit/>
</div>

<div class="features">
  <div class="feature">
    <h2>简单快捷</h2>
    <p>基于spring boot，vuejs，futter快速构建全平台商城系统</p>
  </div>
   
  <div class="feature">
    <h2>支持齐全</h2>
    <p>提供api，后台管理，包含h5,微信小程序，android,ios应用程序完整方案。</p>
  </div>
  <div class="feature">
      <h2>最新技术栈</h2>
      <p>使用Spring Boot2+JPA构建后端服务，<br>vue/element/vux/flutter构建前端界面</p>
   </div> 
</div>
