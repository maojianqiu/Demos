﻿function error(form_obj, errmsg) {
    if (errfound)
        return;
    window.alert(errmsg);
    form_obj.select();
    form_obj.focus();
    errfound = true;
}

function emailCheck() {
    var emailStr = document.form2.email.value;
    if (emailStr != "") {
        var emailPat = /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
        var matchArray = emailStr.match(emailPat);
        if (matchArray == null) {
            return false;
        }
        return true;
    }
    else {
        return true;
    }
}
function fCloseSaveInfo() {
    _gelstn('body')[0].removeChild($$("SaveWin"));
}


function fSaveP2VDo(p) {
    fPopSaveWin("d");
};
