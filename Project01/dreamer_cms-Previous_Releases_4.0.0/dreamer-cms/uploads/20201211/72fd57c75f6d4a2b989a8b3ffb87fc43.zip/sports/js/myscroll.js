//设置通知公告标题自动循环滚动 2020/10/21
var scrollSpeed=80;//值越大，滚动的越慢
min2.innerHTML=min1.innerHTML;
function ScrollMarquee(){
if(min2.offsetTop-father.scrollTop<=0){
father.scrollTop-=min1.offsetHeight;
}else{
    father.scrollTop++;
    }
}
var ScrollTime=setInterval(ScrollMarquee,scrollSpeed);   //设置定时器
father.onmouseover=function(){clearInterval(ScrollTime);};//鼠标放在上面时清除定时器，停止执行滚动函数
father.onmouseout=function(){ScrollTime=setInterval(ScrollMarquee,scrollSpeed);};//鼠标离开，重新滚动