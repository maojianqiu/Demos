var init = function () {
    var _bg3width = $("#content-sec3-adjust").width();
    $("#content-sec3-adjust").css("margin-left", _bg3width * -1 / 2 + "px");
};